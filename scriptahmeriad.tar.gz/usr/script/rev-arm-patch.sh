#!/bin/sh
TEMPATH='/tmp'
cd $TEMPATH
set -e
echo "############ DOWNLOADING FILES #############"
wget -q "http://files.getras.co/rev-arm-patch1.tgz"
echo "############ ARM PATCH 1  ##################"
echo "############ INSTALLATION STARTED ###############"

tar -xzf rev-arm-patch1.tgz -C /
set +e
rm -f rev-arm-patch1.tgz
cd ..
chmod 755 /usr/bin/revcamv2
echo ""
cd ..
sync
echo "############ PATCH IS COMPLETED ############"
echo "############ RESTARTING... #################" 
init 4
sleep 2
init 3
exit 0